import random


print(chr(random.randint(65, 90)))